# Comment faire fonctionner le script STD_01_BorelJaquet.py
1) Extraire le zip STD-01-Borel-Jaquet.zip
2) Ouvrir la solution STD-01-BorelJaquet.sln
3) Vérifier que l'image Lenna.tiff se trouve bien dans le même répertoire que le script Python
4) Exécuter le programme depuis Visual Studio 2019
5) Have Fun 